import s from "./Filters.module.scss";
import cx from "classnames";

export default function Filters() {
    return (
        <div className={s.filteres}>
            <div>
                <h4 className={s.tableHeading}>Table Heading</h4>
            </div>
            <div>
                
            </div>
        </div>
    )
}
