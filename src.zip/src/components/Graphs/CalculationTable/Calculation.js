export const Stockdata =
[
    {
      "S.No": 1,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 355.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 2,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 3,
    "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 1,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 2,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 3,
    "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 1,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 2,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 3,
    "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 5,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 6,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 7,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 1,
      "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 2,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 3,
    "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
    {
      "S.No": 4,
     "SpecularArea": 45.213330,
      "FWHM": 35.213330,
      "MaxIntensity": 30.213330,
      "CenterOffset": 3535.213330,
      "BaselineOffset": 38.213330,
      "SinCurveArea": 28.213330
    },
  ]
 