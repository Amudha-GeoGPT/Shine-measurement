import React from 'react'
import Pages from './Pages/Pages'

const MainPage = () => {
  return (
    <Pages />
  )
}

export default MainPage