import cx from "classnames";
import s from "./Pagination.module.scss";

export default function Pagination() {
    return (
        <div>Pagination</div>
    )
}
