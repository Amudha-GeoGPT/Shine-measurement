import React from 'react';
import Graph from '../Graphs/GraphHeader';
import GraphHeader from '../Graphs/GraphHeader';

const GraphPage = () => {
  return (
    <div>
        <GraphHeader />
        
    </div>
  )
}

export default GraphPage