export const CALCULATION='/getbyswatchname';
export const SWATCHNAME='/swatchname';
export const SWATCHLIST='/getallswatches';
export const UPLOADIMAGE='/uploadImage';
